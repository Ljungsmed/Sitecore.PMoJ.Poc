﻿using System;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Web;
using System.Xml;
using System.Xml.Serialization;
using ServiceProviderSample.SAML;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Xml.Schema;
using System.Text;
using System.Web.UI;
using ServiceProviderSample.Utils;
using System.Web.Hosting;
using System.Security.Cryptography;

namespace ServiceProviderSample.Account
{
    #region using BasePage
    public partial class Logout : BasePage
    #endregion
    #region not using  BasePage
    //public partial class Logout : System.Web.UI.Page /* : BasePage */
    #endregion
    {
        //private static readonly XmlSerializerNamespaces xmlNamespaces = new XmlSerializerNamespaces();
        NameValueCollection appSettings = ConfigurationManager.AppSettings;
        string relayStateToBePersistedAcross = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            string postForm = buildPostForm();
            // utilizando BasePage (Contorna problema de invalidação de viewstate no FA de testes):
            Page p = new Page();
            p.Controls.Add(new LiteralControl(postForm));
            p.ProcessRequest(Context);
            Context.Response.End();
            #region using BasePage
            #endregion
            
            #region not using BasePage --> activar também código comentado na página Logout.aspx
            
            //XmlSerializerNamespaces xmlNamespaces = new XmlSerializerNamespaces();
            //LogoutRequestType _request = new LogoutRequestType();
            //_request.ID = "_" + Guid.NewGuid().ToString();
            //_request.Version = "2.0";
            //_request.IssueInstant = DateTime.UtcNow;
            //_request.Destination = "https://autenticacao.cartaodecidadao.pt/Default.aspx";
            //_request.Consent = "urn:oasis:names:tc:SAML:2.0:logout:user";
            //_request.Issuer = new NameIDType();
            //_request.Issuer.Value = "http://localhost:64181/";
            //_request.NotOnOrAfterSpecified = false;//TODO: significado e utilização
            //_request.SessionIndex = new string[] { };//TODO:

            //NameIDType nameId = new NameIDType();
            //nameId.Format = "urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified";
            //nameId.Value = "urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified";
            //_request.Item = (object)nameId;

            //XmlDocument doc = null;
            //try
            //{
            //    MemoryStream stream = new MemoryStream();
            //    XmlSerializer requestSerializer = new XmlSerializer(_request.GetType());
            //    requestSerializer.Serialize(stream, _request, xmlNamespaces);
            //    stream.Flush();

            //    StreamReader reader = new StreamReader(stream);
            //    stream.Seek(0, SeekOrigin.Begin);
            //    XmlTextReader xmlReader = new XmlTextReader(new StringReader(reader.ReadToEnd()));

            //    XmlSerializer xmlDocumentSerializer = new XmlSerializer(typeof(XmlDocument));
            //    doc = (XmlDocument)xmlDocumentSerializer.Deserialize(xmlReader);
            //    doc.PreserveWhitespace = true;
            //}
            //catch (Exception ex)
            //{
            //    throw new Exception("Erro ao converter objecto para XmlDocument: " + ex.ToString());
            //}

            //string thumbprint = appSettings.Get("CertThumbprint");

            //X509Store store = null;
            //X509Certificate2 cert = null;
            //try
            //{
            //    thumbprint = thumbprint.ToUpper();

            //    store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
            //    store.Open(OpenFlags.ReadOnly);
            //    X509Certificate2Collection certCollection = store.Certificates.Find(X509FindType.FindByThumbprint, thumbprint, false);
            //    cert = certCollection[0];
            //}
            //catch (Exception ex)
            //{
            //    throw new Exception("Excepção ao pesquisar certificado: " + ex.ToString());
            //}
            //finally
            //{
            //    if (store != null)
            //        store.Close();
            //}

            //try
            //{
            //    XmlElement element = doc.DocumentElement;
            //    SignedXml signedXml = new SignedXml(element);
            //    signedXml.SigningKey = cert.PrivateKey;

            //    Reference reference = new Reference("#" + element.Attributes["ID"].Value);

            //    reference.AddTransform(new XmlDsigEnvelopedSignatureTransform());
            //    reference.AddTransform(new XmlDsigExcC14NTransform());

            //    signedXml.AddReference(reference);
            //    signedXml.KeyInfo.AddClause(new KeyInfoX509Data(cert));
            //    signedXml.ComputeSignature();
            //    XmlElement xmlDigitalSignature = signedXml.GetXml();

            //    XmlNode refNode = doc.GetElementsByTagName("Issuer", "urn:oasis:names:tc:SAML:2.0:assertion").Item(0);
            //    element.InsertAfter(xmlDigitalSignature, refNode);
            //}
            //catch (Exception ex)
            //{
            //    throw new Exception("Excepção ao assinar Xml:" + ex.ToString());
            //}

            //this.RelayState.Value = relayStateToBePersistedAcross;

            //this.SAMLRequest.Value = Convert.ToBase64String(Encoding.UTF8.GetBytes(doc.OuterXml));

            //this.form1.Action = appSettings.Get("formActionLogoutDestination");

            #endregion
        }

        // para uso com basePage:
        private string buildPostForm()
        {
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            strBuilder.AppendLine("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\"");
            strBuilder.AppendLine("\"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">");
            strBuilder.AppendLine("<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\">");
            strBuilder.AppendLine("<body onload='document.forms[0].submit()'>");
            strBuilder.AppendLine("<form id='form1' action='" + appSettings.Get("formActionLogoutDestination") + "' method='POST' runat=\"server\">");
            strBuilder.AppendLine("<div>");
            strBuilder.AppendLine("<input type='hidden' name='SAMLRequest' value='" + buildSamlField() + "' />");
            strBuilder.AppendLine("<input type='hidden' name='RelayState' value='' />");
            strBuilder.AppendLine("</div>");
            strBuilder.AppendLine("<noscript>");
            strBuilder.AppendLine("<div>");
            strBuilder.AppendLine("<p>");
            strBuilder.AppendLine("<strong>Atenção: </strong>O seu <i>Browser</i> não suporta Javascript. ");
            strBuilder.AppendLine("Para prosseguir deve clicar no botão \"Continuar\".");
            strBuilder.AppendLine("</p>");
            strBuilder.AppendLine("</div>");
            strBuilder.AppendLine("<div>");
            strBuilder.AppendLine("<input type='submit' value='Continuar' />");
            strBuilder.AppendLine("</div>");
            strBuilder.AppendLine("</noscript>");
            strBuilder.AppendLine("</form>");
            strBuilder.AppendLine("</body>");
            strBuilder.AppendLine("</html>");
            return strBuilder.ToString();
        }

        string buildSamlField()
        {
            NameValueCollection appSettings = ConfigurationManager.AppSettings;
            XmlSerializerNamespaces xmlNamespaces = new XmlSerializerNamespaces();
            LogoutRequestType _request = new LogoutRequestType();
            _request.ID = "_" + Guid.NewGuid().ToString();
            _request.Version = "2.0";
            _request.IssueInstant = DateTime.UtcNow;
            _request.Destination = "https://autenticacao.cartaodecidadao.pt/Default.aspx";
            _request.Consent = "urn:oasis:names:tc:SAML:2.0:logout:user";
            _request.Issuer = new NameIDType();
            //_request.Issuer.Value = "http://localhost:64181/";
            _request.Issuer.Value = appSettings.Get("issuer");
            _request.NotOnOrAfterSpecified = false;//TODO: significado e utilização
            _request.SessionIndex = new string[] { };//TODO:

            NameIDType nameId = new NameIDType();
            nameId.Format = "urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified";
            nameId.Value = "urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified";
            _request.Item = (object)nameId;

            XmlDocument doc = null;
            try
            {
                MemoryStream stream = new MemoryStream();
                XmlSerializer requestSerializer = new XmlSerializer(_request.GetType());
                requestSerializer.Serialize(stream, _request, xmlNamespaces);
                stream.Flush();

                StreamReader reader = new StreamReader(stream);
                stream.Seek(0, SeekOrigin.Begin);
                XmlTextReader xmlReader = new XmlTextReader(new StringReader(reader.ReadToEnd()));

                XmlSerializer xmlDocumentSerializer = new XmlSerializer(typeof(XmlDocument));
                doc = (XmlDocument)xmlDocumentSerializer.Deserialize(xmlReader);
                doc.PreserveWhitespace = true;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao converter objecto para XmlDocument: " + ex.ToString());
            }

            // Assinatura:
            X509Certificate2 cert = new X509Certificate2(HostingEnvironment.MapPath("~/SAML/Certificate/") + appSettings.Get("SamlCertificateName"), appSettings.Get("SamlCertificatePassword"));
            RSACryptoServiceProvider rsaCsp = (RSACryptoServiceProvider)cert.PrivateKey;

            //string thumbprint = appSettings.Get("CertThumbprint");

            //X509Store store = null;
            //X509Certificate2 cert = null;
            //try
            //{
            //    thumbprint = thumbprint.ToUpper();

            //    store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
            //    store.Open(OpenFlags.ReadOnly);
            //    X509Certificate2Collection certCollection = store.Certificates.Find(X509FindType.FindByThumbprint, thumbprint, false);
            //    cert = certCollection[0];
            //}
            //catch (Exception ex)
            //{
            //    throw new Exception("Excepção ao pesquisar certificado: " + ex.ToString());
            //}
            //finally
            //{
            //    if (store != null)
            //        store.Close();
            //}

            try
            {
                XmlElement element = doc.DocumentElement;
                SignedXml signedXml = new SignedXml(element);
                signedXml.SigningKey = cert.PrivateKey;

                Reference reference = new Reference("#" + element.Attributes["ID"].Value);

                reference.AddTransform(new XmlDsigEnvelopedSignatureTransform());
                reference.AddTransform(new XmlDsigExcC14NTransform());

                signedXml.AddReference(reference);
                signedXml.KeyInfo.AddClause(new KeyInfoX509Data(cert));
                signedXml.ComputeSignature();
                XmlElement xmlDigitalSignature = signedXml.GetXml();

                XmlNode refNode = doc.GetElementsByTagName("Issuer", "urn:oasis:names:tc:SAML:2.0:assertion").Item(0);
                element.InsertAfter(xmlDigitalSignature, refNode);
            }
            catch (Exception ex)
            {
                throw new Exception("Excepção ao assinar Xml:" + ex.ToString());
            }

            return Convert.ToBase64String(Encoding.UTF8.GetBytes(doc.OuterXml));
        }
    }
}