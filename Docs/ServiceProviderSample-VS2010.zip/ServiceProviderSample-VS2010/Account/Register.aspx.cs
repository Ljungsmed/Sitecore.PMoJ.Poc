﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ServiceProviderSample.Account
{
    public partial class Register : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ((LinkButton)this.Master.FindControl("LinkButtonHome")).Style.Remove("font-weight");
                ((LinkButton)this.Master.FindControl("LinkButtonPrivate")).Style.Remove("font-weight");

                if (Session["Nic"] != null && (!string.IsNullOrEmpty((string)Session["Nic"])))
                {
                    ((TextBox)this.RegisterUserWizardStep.ContentTemplateContainer.FindControl("UserName")).Text = (string)Session["Nic"];
                    if (Session["RelayState"] != null && (!string.IsNullOrEmpty((string)Session["RelayState"])))
                        RegisterUser.ContinueDestinationPageUrl = HttpUtility.UrlEncode((string)Session["RelayState"]);
                }
                else
                    RegisterUser.ContinueDestinationPageUrl = Request.QueryString["ReturnUrl"];
            }
        }

        protected void RegisterUser_CreatedUser(object sender, EventArgs e)
        {
            FormsAuthentication.SetAuthCookie(RegisterUser.UserName, false /* createPersistentCookie */);

            string continueUrl = RegisterUser.ContinueDestinationPageUrl;
            if (String.IsNullOrEmpty(continueUrl))
            {
                continueUrl = "~/";
            }
            Response.Redirect(continueUrl);
        }

    }
}
