﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Specialized;
using System.Configuration;

namespace ServiceProviderSample.Account
{
    public partial class Login : System.Web.UI.Page
    {
        NameValueCollection appSettings = ConfigurationManager.AppSettings;
        protected string idpUrl = string.Empty; 


        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Response.Cache.SetCacheability(HttpCacheability.NoCache);

            if (!IsPostBack)
            {
                idpUrl = appSettings.Get("idpTestAuthnUrl") + "?id=" + DateTime.Now.Ticks; 

                ((LinkButton)this.Master.FindControl("LinkButtonHome")).Style.Remove("font-weight");
                ((LinkButton)this.Master.FindControl("LinkButtonPrivate")).Style.Remove("font-weight");
            }

            RegisterHyperLink.NavigateUrl = "Register.aspx?ReturnUrl=" + HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
            ImageButtonLoginCC.PostBackUrl = "SendRequest.aspx?ReturnUrl=" + HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
        }
    }
}
