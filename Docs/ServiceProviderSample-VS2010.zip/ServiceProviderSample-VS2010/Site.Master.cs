﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using ServiceProviderSample.SAML;
using System.Xml;
using System.IO;
using System.Xml.Serialization;
using System.Collections.Specialized;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Configuration;
using ServiceProviderSample.Account;
using ServiceProviderSample.Utils;

namespace ServiceProviderSample
{
    public partial class SiteMaster : System.Web.UI.MasterPage 
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LoginStatus_LoggedOut(object sender, EventArgs e)
        {
            Response.Redirect(VirtualPathUtility.ToAbsolute("~/Account/Logout.aspx"));
        }
    }
}
